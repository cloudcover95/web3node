import yfinance as yf
import pandas as pd
import numpy as np
import requests
import os
import json
import logging
import warnings

# Suppress YFinance noise
logging.getLogger('yfinance').setLevel(logging.CRITICAL)
warnings.filterwarnings("ignore", category=FutureWarning)

logger = logging.getLogger("OmniDataLayer")

class OmniDataLayer:
    def __init__(self, vault_path):
        self.vault = vault_path
        self.blacklist_file = os.path.join(os.path.dirname(self.vault), "dynamic_blacklist.json")
        self.dynamic_blacklist = set(self._load_blacklist())
        # Safe TradFi list to prevent YF from spamming 404s on pure Web3 tokens
        self.yf_safe_list = ['BTC-USD', 'ETH-USD', 'SOL-USD', 'XRP-USD', 'DOGE-USD', 'LINK-USD', 'ADA-USD', 'BNB-USD', 'LTC-USD']

    def _load_blacklist(self):
        if os.path.exists(self.blacklist_file):
            try:
                with open(self.blacklist_file, 'r') as f:
                    return json.load(f)
            except: pass
        return []

    def _save_blacklist(self):
        try:
            with open(self.blacklist_file, 'w') as f:
                json.dump(list(self.dynamic_blacklist), f, indent=4)
        except Exception as e:
            logger.error(f"Failed to save blacklist: {e}")

    def fetch_robust_history(self, ticker, cg_id=None, resolution="INTRADAY"):
        """V134: Indented inside class. Captures Price + Volume for the Fluid Engine."""
        if ticker in self.dynamic_blacklist: 
            return None
        
        df = None

        # 1. Primary: TradFi High-Res Engine (Yahoo Finance)
        try:
            c = {"INTRADAY": {"period": "60d", "interval": "15m"}}[resolution]
            raw = yf.download(ticker, period=c["period"], interval=c["interval"], progress=False)
            if not raw.empty:
                # Capture Volume alongside Close for Fluid Dynamics
                if not isinstance(raw.columns, pd.MultiIndex):
                    df = raw[['Close', 'Volume']].copy()
                else:
                    df = pd.DataFrame({
                        'Close': raw['Close'].iloc[:, 0],
                        'Volume': raw['Volume'].iloc[:, 0]
                    })
                df.columns = ['price', 'volume']
        except: 
            pass

        # 2. Secondary: Web3 Native Pipeline (CoinGecko Deep Chart fallback)
        if df is None or df.empty:
            _id = cg_id if cg_id else ticker.split('-')[0].lower()
            try:
                url = f"https://api.coingecko.com/api/v3/coins/{_id}/market_chart?vs_currency=usd&days=14"
                r = requests.get(url, timeout=5).json()
                prices = r.get('prices', [])
                volumes = r.get('total_volumes', []) 
                
                if prices and volumes:
                    logger.info(f"YF 404 on {ticker}. Engaging Web3 Fallback matrix...")
                    p_df = pd.DataFrame(prices, columns=['Timestamp', 'price'])
                    v_df = pd.DataFrame(volumes, columns=['Timestamp', 'volume'])
                    
                    # Merge Price and Volume on exact timestamps
                    df = pd.merge(p_df, v_df, on='Timestamp')
                    df['Timestamp'] = pd.to_datetime(df['Timestamp'], unit='ms')
                    df.set_index('Timestamp', inplace=True)
            except: 
                pass

        # 3. Matrix Validation & Calculus
        if df is None or df.empty or len(df) < 30:
            logger.warning(f"Terminal Ghosting: {ticker}. Adding to persistent blacklist.")
            self.dynamic_blacklist.add(ticker)
            self._save_blacklist()
            return None

        # Clean volume NaNs and price continuity
        df['volume'] = df['volume'].fillna(0)
        df = df.dropna(subset=['price'])
        
        # Vectorized Math
        df['Returns'] = df['price'].pct_change().fillna(0)
        window = 30
        rolling_median = df['price'].rolling(window).median()
        rolling_mad = (df['price'] - rolling_median).abs().rolling(window).median()
        df['Robust_Z'] = (df['price'] - rolling_median) / ((rolling_mad * 1.4826) + 1e-9)

        return df, df['price'].values